import glob,json,statistics as st,sys,math
from pathlib import Path
def stats(a):
 if not a:return {}
 s=sorted(a);return {'n':len(s),'median':round(st.median(s),2),'p95':round(s[math.ceil(len(s)*.95)-1],2),'max':round(s[-1],2)}
def diff(a):return [y-x for x,y in zip(a,a[1:])]
def load(f):
 j=json.load(open(f));steps=j['steps'];frames=[r for r in j['frames'] if steps[0]['t']<=r['t']<=steps[-1]['t']];times=[r['t'] for r in frames];subs=[r['t'] for i,r in enumerate(frames) if i and r.get('draws')!=frames[i-1].get('draws')]
 freezes=[b for a,b in zip(frames,frames[1:]) if b.get('rider',0)-a.get('rider',0)>.02 and a.get('phase')==b.get('phase')]
 return {'stepGap':stats(diff([r['t'] for r in steps])),'frameGap':stats(diff(times)),'submitGap':stats(diff(subs)),'patchCpu':stats([r['ms'] for r in j['patches']]),'seatError':stats([abs(r['seatOffset']) for r in frames if 'seatOffset'in r]),'gaitStalls':len(freezes),'tileEnd':j['routeEnd'],'steps':len(steps)}
if __name__=='__main__':
 out={Path(f).stem:load(f) for f in sorted(glob.glob(sys.argv[1]+'/*.json')) if 'normal-' in f or 'shadow-' in f or 'pixels-' in f}
 print(json.dumps(out,indent=2))
