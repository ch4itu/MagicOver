const fs=require('node:fs'),assert=require('node:assert/strict'),hash=require('node:crypto').createHash;
function realm(f){const html=fs.readFileSync(f,'utf8');return new Function(html.split('<script data-source="farlands-map.js">')[1].split('</script>')[0]+'\nreturn Farlands')();}
const old=realm('horse-base.html'),current=realm('MagicOver/eternalbliss/index.html');
function run(F){
 const world=new F.Terrain(),gaps=[],seq=[],sha=hash('sha256');
 for(let x=4967;x<4967+192;x++){
  const t=performance.now();
  for(let z=4604-27;z<=4604+27;z++)for(const offset of [-27,0,27])seq.push(world.tileAt(x+offset,z));
  gaps.push(performance.now()-t);
 }
 for(let z=0;z<128;z++)for(let x=0;x<128;x++)seq.push(world.tileAt(4900+x,4560+z));
 for(let n=0;n<97;n++)seq.push(world.tileAt(n*37,n*42));
 for(let i=0;i<12;i++){
  const x=4967+i,y=4604;world.setTile(x,y,'road');assert.equal(world.tileAt(x,y),'road');
 }
 for(const xy of [[0,0],[9999,9999],[10000,10],[-1,1],[1,.5]])seq.push(world.tileAt(...xy));
 assert(world.chunks.size<=80);
 sha.update(JSON.stringify(seq));gaps.sort((a,b)=>a-b);
 return {samples:seq.length,sha:sha.digest('hex'),p95:gaps[Math.ceil(gaps.length*.95)-1],max:gaps.at(-1)};
}
let result=[];for(let i=0;i<4;i++){const a=run(i%2?current:old),b=run(i%2?old:current);assert.equal(a.sha,b.sha);result.push(i%2?{base:b,candidate:a}:{base:a,candidate:b});}console.log(JSON.stringify(result));
