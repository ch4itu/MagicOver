const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const html=fs.readFileSync('MagicOver/eternalbliss/index.html','utf8');
const script=n=>html.split('<script data-source="'+n+'">')[1].split('</script>')[0];
const ctx=vm.createContext({console});
function run(code){return vm.runInContext(code,ctx)}
run(script('three.min.js')); run(script('bliss-map.js'));
const sizes=html.slice(html.indexOf('const BUILDING_FOOTPRINTS ='),html.indexOf('const buildingFootprintOf'));
const gui=script('gui.js');
run(`const EternalBlissArt={}, worldClimate={season:'Summer'},sharedWorld={active:()=>true},ebFarlands={surface:()=>false};
const buildingInterior=null,gameState={world:BLISS_MAP_DATA,player:{x:75,y:75}},adventureTile=(x,z)=>BLISS_MAP_DATA.terrain[z]?.[x],buildingFootprints=new Set(),minimapTerrainRevision=0,buildingFootprintRevision=0;`+sizes+`
for(const b of BLISS_MAP_DATA.buildings){const [x,z,w,h]=BUILDING_FOOTPRINTS.get([b.x,b.y,b.type].join(','))||[b.x,b.y,1,1];for(let i=x;i<x+w;i++)for(let j=z;j<z+h;j++)buildingFootprints.add(j*300+i);}
` + gui.slice(gui.indexOf('    const T = THREE;'),gui.indexOf('    function setup()'))+`
globalThis.create=()=>{const v=Object.create(WorldView.prototype);v.scene=new T.Scene();v.eyeMode=true;v.swiftShader=true;v.room=null;v.visibleRadius=()=>17;
`+gui.slice(gui.indexOf('            this.trunk = new T.CylinderGeometry'),gui.indexOf('            this.glowMaterial =')).replaceAll('this.','v.')+`
v.ground=v.terrainMaterial=v.shallowsMaterial=v.glowMaterial=new T.MeshBasicMaterial();return v;};`);
const T=ctx.THREE;
const probe=(group)=>{
const poses=[0,Math.PI/2,Math.PI,Math.PI*1.5];
group.updateMatrixWorld(true);
const rows=[];
for(const yaw of poses){
const camera=new T.PerspectiveCamera(72,900/420,.055,110);
camera.rotation.order='YXZ';camera.position.set(75,1.135,75);camera.rotation.set(-.055,yaw,0);camera.updateMatrixWorld();
const frustum=new T.Frustum().setFromProjectionMatrix(new T.Matrix4().multiplyMatrices(camera.projectionMatrix,camera.matrixWorldInverse));
let tris=0,total=0,calls=0;
for(const mesh of group.children){
 const n=(mesh.geometry.index||mesh.geometry.attributes.position).count/3*(mesh.isInstancedMesh?mesh.count:1);
 total+=n;if(!mesh.frustumCulled||frustum.intersectsObject(mesh)){tris+=n;calls++;}
}
rows.push({yaw,total,tris,calls});}
return rows;
};
const v=ctx.create();v.updateTerrain();
const current=probe(v.land);
const parts=new T.Group();
for(let z=12;z<140;z+=24)for(let x=12;x<140;x+=24){const g=v.buildTerrain(x,z,Math.min(x+24,140),Math.min(z+24,140),true);parts.add(...[...g.children]);}
const partitioned=probe(parts);assert.equal(current[0].total,partitioned[0].total);console.log(JSON.stringify({current,partitioned}));
