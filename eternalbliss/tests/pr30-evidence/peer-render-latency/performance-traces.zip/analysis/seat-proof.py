import sys,json,base64,subprocess,hashlib
from pathlib import Path
d=Path(sys.argv[1]);pub={r['owner'] for r in map(json.loads,(d/'peer-events.jsonl').read_text().splitlines()) if r['kind']=='join'}
world='GjYsCcq2r5KkVab7suzvStwYkAcJ3nTe9yXN8EcC5T9E'
q={'method':'getAccountInfo','id':10,'jsonrpc':'2.0','params':[world,{'encoding':'base64','commitment':'finalized'}]}
reply=json.loads(subprocess.check_output(['curl','-fsS','--max-time','20','-H','Content-Type: application/json','--data-binary','@-','https://devnet-as.magicblock.app'],input=json.dumps(q).encode()))['result']
b=base64.b64decode(reply['value']['data'][0]);assert reply['value']['owner']=='6e5ied8gFYVSEoc6wWGwBwVSFAC9DZNYAgKg53M1rGdb' and len(b)==5380
alphabet='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
def key(s):
 n=0
 for c in s:n=n*58+alphabet.index(c)
 return n.to_bytes(32,'big')
found=[s for s in pub if any(b[64+112*i:96+112*i]==key(s) for i in range(32))]
proof={'world':world,'slot':reply['context']['slot'],'commitment':'finalized','worldSHA256':hashlib.sha256(b).hexdigest(),'testedOwners':sorted(pub),'seatsStillOccupiedByTestPlayers':found}
(d/'seat-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(proof);assert not found
