import json,sys,subprocess
from pathlib import Path
d=Path(sys.argv[1]); builds={}
for r in map(json.loads,(d/'peer-events.jsonl').read_text().splitlines()):
 if r['kind']!='receipts':continue
 sigs=list(dict.fromkeys(r['acknowledged']));req=dict(jsonrpc='2.0',id=17,method='getSignatureStatuses',params=[sigs,{'searchTransactionHistory':True}])
 data=subprocess.check_output(['curl','-fsS','--max-time','20','--retry','1','-H','Content-Type: application/json','--data-binary','@-','https://devnet-as.magicblock.app'],input=json.dumps(req).encode())
 ans=json.loads(data)['result'];builds[r['sha']]={'observationSlot':ans['context']['slot'],'acknowledged':[{'signature':s,'status':st} for s,st in zip(sigs,ans['value'],strict=True)]}
 print(r['sha'][:8],len(sigs),sum(1 for x in ans['value'] if x and x['confirmationStatus']=='finalized' and x['err'] is None))
(d/'ack-finality.json').write_text(json.dumps(builds,indent=2)+'\n')
