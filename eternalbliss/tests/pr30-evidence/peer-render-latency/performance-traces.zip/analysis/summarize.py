import sys,json,glob,math,statistics,collections
from pathlib import Path
def pct(a,q):
 return round(sorted(a)[max(0,math.ceil(q*len(a))-1)],1) if a else None
def stats(a):
 return {'n':len(a),'median':round(statistics.median(a),1) if a else None,'p95':pct(a,.95),'raw':[round(x,1) for x in a]} if len(a)<10 else {'n':len(a),'median':round(statistics.median(a),1),'p95':pct(a,.95)}
def summary(folder):
 rows=list(map(json.loads,Path(folder,'peer-events.jsonl').read_text().splitlines())); out={}
 for sha in dict.fromkeys(r['sha'] for r in rows):
  builds=out[sha]={}
  for mode in ['2d','fp']:
   moves=[r for r in rows if r['kind']=='move' and r['mode']==mode and r['sha']==sha]
   d=builds[mode]={}
   for label,a,b in [('inputToSigned','sign','input'),('signedToSubmit','httpStart','sign'),('submitToHttpHeaders','httpHeaders','httpStart'),('submitToAccount','arrival','httpStart'),('decodeAndReconcile','ingested','arrival'),('ingestedToPlacement','placed','ingested'),('submitToPlacement','placed','httpStart'),('inputToPlacement','placed','input')]:
    d[label]=stats([r[a]-r[b] for r in moves if r.get(a) and r.get(b)])
   samples=collections.defaultdict(list);counts=collections.Counter()
   for f in sorted(Path(folder).glob(sha[:8]+'-'+mode+'-*.json')):
    data=json.load(open(f));submissions=[e for e in data if e['kind']==('scene' if mode=='fp' else 'classic')]
    samples['placementFrameIntervals']+= [v['t']-u['t'] for u,v in zip(submissions,submissions[1:])]
    samples['triangles'] += [e['triangles'] for e in submissions if 'triangles' in e]
    samples['drawCalls'] += [e['calls'] for e in submissions if 'calls' in e]
    for i,e in enumerate(data):
     if e['kind']=='ingested':
      lastarrival=next((j for j in range(i-1,-1,-1) if data[j]['kind']=='arrival' and data[j]['slot']==e['slot']),None)
      if lastarrival is not None and lastarrival>0:
       prev=data[lastarrival-1]
       counts['wsToWorld' if prev['kind']=='ws' and prev['slot']==e['slot'] else 'otherWorld']+=1
    samples['worldReadHeaders'] += [e['t']-e['start'] for e in data if e['kind']=='http' and e['method']=='getMultipleAccounts']
   d.update({k:stats(v) for k,v in samples.items()});d['sourceCounts']=counts
 return out
if __name__=='__main__': print(json.dumps(summary(sys.argv[1]),indent=2))
