import concurrent.futures,json,subprocess,sys
from pathlib import Path
folder=Path(sys.argv[1])
rows=list(map(json.loads,(folder/'peer-events.jsonl').read_text().splitlines()))
def rpc(url,method,params):
 data=json.dumps(dict(jsonrpc='2.0',id=17,method=method,params=params))
 r=subprocess.run(['curl','-fsS','--retry','2','--max-time','20','-H','Content-Type: application/json','--data-binary','@-',url],input=data,text=True,capture_output=True,check=True)
 a=json.loads(r.stdout);assert 'error' not in a,a.get('error');return a['result']
def read_move(m):
 url='https://devnet-as.magicblock.app'; sig=m['id']
 tx=rpc(url,'getTransaction',[sig,{'encoding':'json','commitment':'finalized','maxSupportedTransactionVersion':0}]); assert tx and tx['meta']['err'] is None
 return dict(build=m['sha'],mode=m['mode'],slot=tx['slot'],signature=sig,signer=tx['transaction']['message']['accountKeys'][0],fee=tx['meta']['fee'],preBalance=tx['meta']['preBalances'][0],postBalance=tx['meta']['postBalances'][0])
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 moves=list(pool.map(read_move,[r for r in rows if r['kind']=='move']))
p=folder/'verified-movement-receipts.json';p.write_text(json.dumps(moves,indent=2)+'\n')
print(len(moves),'finalized moves; fees',set(r['fee'] for r in moves),'signer balances',set(r['postBalance'] for r in moves))
